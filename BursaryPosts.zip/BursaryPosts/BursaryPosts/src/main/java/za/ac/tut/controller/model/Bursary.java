package za.ac.tut.controller.model;

public class Bursary {
    private String id;
    private String bursary_name;
    private  String bursary_requirements;
    private String courses;
    private String bursary_email;
    private String bursary_link;

    public Bursary() {

    }

    public Bursary(String id,String bursary_name, String bursary_requirements, String courses, String bursary_email, String bursary_link) {
        this.id =id;
        this.bursary_name = bursary_name;
        this.bursary_requirements = bursary_requirements;
        this.courses = courses;
        this.bursary_email = bursary_email;
        this.bursary_link = bursary_link;
    }

    public String get_Id() {
        return id;
    }

    public void set_Id(String id) {
        this.id = id;
    }

    public String getBursary_name() {
        return bursary_name;
    }

    public void setBursary_name(String bursary_name) {
        this.bursary_name = bursary_name;
    }

    public String getBursary_requirements() {
        return bursary_requirements;
    }

    public void setBursary_requirements(String bursary_requirements) {
        this.bursary_requirements = bursary_requirements;
    }

    public String getCourses() {
        return courses;
    }

    public void setCourses(String courses) {
        this.courses = courses;
    }

    public String getBursary_email() {
        return bursary_email;
    }

    public void setBursary_email(String bursary_email) {
        this.bursary_email = bursary_email;
    }

    public String getBursary_link() {
        return bursary_link;
    }

    public void setBursary_link(String bursary_link) {
        this.bursary_link = bursary_link;
    }

    @Override
    public String toString() {
        return "Bursary{" +
                "bursary_name='" + bursary_name + '\'' +
                ", bursary_requirements='" + bursary_requirements + '\'' +
                ", courses='" + courses + '\'' +
                ", bursary_email='" + bursary_email + '\'' +
                ", bursary_link='" + bursary_link + '\'' +
                '}';
    }
}
