package za.ac.tut.controller.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import za.ac.tut.controller.model.Bursary;
import za.ac.tut.controller.repository.BursaryServices;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/bursary")
public class BursaryController {

    @Autowired
    private BursaryServices bursaryServices;

    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public String saveBursary(@RequestBody Bursary bursary) {
        bursaryServices.saveOrUpdate(bursary);
        return bursary.get_Id();
    }

    @GetMapping("/getall")
    @ResponseStatus(HttpStatus.OK)
    public Iterable<Bursary> getAllBursaries() {
        return bursaryServices.listAll();
    }

    @PutMapping("/edit/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Bursary updateBursary(@RequestBody Bursary bursary, @PathVariable("id") String id) {
        bursary.set_Id(id);
        bursaryServices.saveOrUpdate(bursary);
        return bursary;
    }

    @DeleteMapping("/delete/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteBursary(@PathVariable("id") String id) {
        bursaryServices.deleteBursary(id);
    }

    @GetMapping("/search/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Bursary getBursaryById(@PathVariable("id") String id) {
        return bursaryServices.getBursaryByID(id);
    }
}
