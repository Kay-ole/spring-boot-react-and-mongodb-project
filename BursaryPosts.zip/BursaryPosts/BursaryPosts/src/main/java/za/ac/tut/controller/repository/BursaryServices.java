package za.ac.tut.controller.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.tut.controller.model.Bursary;
import za.ac.tut.controller.exception.ResourceNotFoundException;

import java.util.Optional;

@Service
public class BursaryServices {

    @Autowired
    private BursaryRepo repo;

    public void saveOrUpdate(Bursary bursary) {
        repo.save(bursary);
    }

    public Iterable<Bursary> listAll() {
        return repo.findAll();
    }

    public void deleteBursary(String id) {
        if (!repo.existsById(id)) {
            throw new ResourceNotFoundException("Bursary not found with id: " + id);
        }
        repo.deleteById(id);
    }

    public Bursary getBursaryByID(String bursaryId) {
        return repo.findById(bursaryId)
                .orElseThrow(() -> new ResourceNotFoundException("Bursary not found with id: " + bursaryId));
    }
}
