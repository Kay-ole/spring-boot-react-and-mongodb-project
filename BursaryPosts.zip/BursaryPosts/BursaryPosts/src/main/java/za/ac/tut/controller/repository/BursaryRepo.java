package za.ac.tut.controller.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import za.ac.tut.controller.model.Bursary;

@Repository
public interface BursaryRepo extends MongoRepository<Bursary,String> {
}
