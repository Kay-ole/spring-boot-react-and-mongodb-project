package com.bursaryPost.BursaryPosts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BursaryPostsApplicationTests {

	@Test
	void contextLoads() {
	}

}
